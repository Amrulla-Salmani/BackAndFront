import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from '../Components/login/login.component';
// import { AppComponent } from '../app.component';
// import { RegisterComponent } from '../Components/register/register.component';
import { LogoutComponent } from '../Components/logout/logout.component';
import { DisplayAirlineComponent } from '../Components/Airline/display-airline/display-airline.component';
import { AddAirlineComponent } from '../Components/Airline/add-airline/add-airline.component';
import { AirlinesComponent } from '../Components/airlines/airlines.component';
import { AppComponent } from '../app.component';
import { AuthGuard } from '../gaurd/auth.guard';
import { AddInventoryComponent } from '../Components/Inventory/add-inventory/add-inventory.component';
import { DisplayInventoryComponent } from '../Components/Inventory/display-inventory/display-inventory.component';
import { SeachInventoryComponent } from '../Components/Inventory/seach-inventory/seach-inventory.component';
import { RegisterComponent } from '../Components/register/register.component';
import { BookingsComponent } from '../Components/bookings/bookings.component';
import { DisplayBookesDetailsComponent } from '../Components/display-bookes-details/display-bookes-details.component';
// import { DisplayBookingsComponent } from '../Components/bookings/display-bookings/display-bookings.component';
// import { InventoryComponent } from '../Components/inventory/inventory.component';
// import { DisplayAirlineComponent } from '../Components/airline/airline.component';

const route : Routes=[

  
  {path:'',component:AppComponent},
  {path:'register',component:RegisterComponent},
  {path:'login',component:LoginComponent},
  {path:'display-airline',component:DisplayAirlineComponent,canActivate:[AuthGuard]},//Here we are mapping our controller to nav bar
  {path:'add-airline',component:AddAirlineComponent,canActivate:[AuthGuard]},
  {path:'airlines',component:AirlinesComponent,canActivate:[AuthGuard]},
  {path:'add-inventory',component:AddInventoryComponent,canActivate:[AuthGuard]},
  {path:'logout',component:LogoutComponent},
  {path:'display-inventory',component:DisplayInventoryComponent,canActivate:[AuthGuard]},
  {path:'search-inventory',component:SeachInventoryComponent,canActivate:[AuthGuard]},
  {path:'Book-ticket',component:BookingsComponent,canActivate:[AuthGuard]},
  {path:'display-bookings',component:DisplayBookesDetailsComponent,canActivate:[AuthGuard]}
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forRoot(route)
  ],
  exports:[RouterModule]
})
export class AppRoutingModule { }
