import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  CanActivate,
  RouterStateSnapshot,
  UrlTree,
} from '@angular/router';
import { Observable } from 'rxjs';
import { RouterService } from '../Services/router.service';

@Injectable({
  providedIn: 'root',
})
export class AuthGuard implements CanActivate {
  constructor(private routerservice: RouterService) {}
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ):
    | Observable<boolean | UrlTree>
    | Promise<boolean | UrlTree>
    | boolean
    | UrlTree {
      let userTokenExist = this.routerservice.getUserToken();

      let userTokenStatus: boolean = getUserTokenStatus(userTokenExist)
    // let UserStatus: boolean = false;
    if (userTokenStatus) {
      return true;
    } else {
      this.routerservice.gotoLogin();
    }
    return userTokenStatus;
    // return false; //If we set false then those API will not work which is can activated in app routing module
  }
}
function getUserTokenStatus(userTokenExist: string | null): boolean {
  if (userTokenExist != null) {
    return true;
  }
  else {
    return false;
  }
}

