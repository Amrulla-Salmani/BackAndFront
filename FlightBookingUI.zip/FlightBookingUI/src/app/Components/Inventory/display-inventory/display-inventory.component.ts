import { Component, OnInit } from '@angular/core';
import { Inventory } from 'src/app/Model/inventory';
import { InventoryService } from 'src/app/Services/inventory.service';
import { RouterService } from 'src/app/Services/router.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-display-inventory',
  templateUrl: './display-inventory.component.html',
  styleUrls: ['./display-inventory.component.css'],
})
export class DisplayInventoryComponent implements OnInit {
  inventories?: Inventory[];
  constructor(private inventoryservice: InventoryService,private routerservice:RouterService) {}

  // dataSource =this.getallInventories();

  ngOnInit(): void {
    debugger;
    this.inventoryservice.getAllInventories().subscribe({
      next: (res) => {
        debugger;
        console.log(res);
        this.inventories = res;
      },
      error: (e) => {
        debugger;
        console.log(e);
        Swal.fire('Error', 'Get All Airlines', 'error');
      },
    });
  }
  gotoAddInventory(){
    this.routerservice.gotoAddInventory();
    }
}
