import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup,Validators } from '@angular/forms';
import { Airline } from 'src/app/Model/airline';
import { Inventory } from 'src/app/Model/inventory';
import { AirlineService } from 'src/app/Services/airline.service';
import { InventoryService } from 'src/app/Services/inventory.service';
import { RouterService } from 'src/app/Services/router.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-inventory',
  templateUrl: './add-inventory.component.html',
  // styleUrls: ['./add-inventory.component.css'],

})
export class AddInventoryComponent implements OnInit {
  // InventoryForm: FormGroup;
  inventory: Inventory;
  floatLabelControl=new FormControl('auto');
  AirlineList:Airline[]|undefined;
  // mycontrol= new FormControl();
  constructor(
    private routerservice: RouterService,
    private inventoryservice: InventoryService,
    private airlineservice: AirlineService
    //  ,formBuilder: FormBuilder
  ) 
  {
    // this.InventoryForm = formBuilder.group({
    //   // hideRequired: this.hideRequiredControl,
    //   floatLabel: this.floatLabelControl,      
    //   airlines:['']
    // })
     this.inventory = new Inventory();

    //  this.inventory.airId=this.InventoryForm.value.airlines;

    
    //  this.InventoryForm = formBuilder.group({
    //   name: [
    //     // '',
    //     // Validators.compose([Validators.required, Validators.minLength(5)]),
    //   ],
    //   password: [
    //     // '',
    //     // Validators.compose([Validators.required, Validators.minLength(5)]),
    //   ],
    // });
  }

  ngOnInit(): void {
    this.airlineservice.getAllAirlines().subscribe(res=>{
      this.AirlineList=res;
      });
  }
  // addInventory(InventoryForm:FormGroup) {
    addInventory() {
    debugger;
    // alert(this.InventoryForm.value.airlines);
    this.inventoryservice.addInventory(this.inventory).subscribe((res: any) => {
      debugger;
      console.log(`The Add Airline Result:${res}`);
      if (res == true) {
        debugger;
        Swal.fire('Inventory Details', 'Added Succesfully!!', 'success');
        this.routerservice.gotoInventories();
      } else {
        debugger;
        this.routerservice.gotoLogin();
      }
    });
  }
}
