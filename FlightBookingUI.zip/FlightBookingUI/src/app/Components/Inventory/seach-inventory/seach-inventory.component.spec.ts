import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SeachInventoryComponent } from './seach-inventory.component';

describe('SeachInventoryComponent', () => {
  let component: SeachInventoryComponent;
  let fixture: ComponentFixture<SeachInventoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SeachInventoryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SeachInventoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
