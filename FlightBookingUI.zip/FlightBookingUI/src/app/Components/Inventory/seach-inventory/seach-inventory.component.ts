import { Component, OnInit } from '@angular/core';
import { Inventory } from 'src/app/Model/inventory';
import { SearchInventory } from 'src/app/Model/search-inventory';
import { InventoryService } from 'src/app/Services/inventory.service';
import { RouterService } from 'src/app/Services/router.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-seach-inventory',
  templateUrl: './seach-inventory.component.html',
  styleUrls: ['./seach-inventory.component.css'],
})
export class SeachInventoryComponent implements OnInit {
  inventories?: Inventory[];
  inventories1: SearchInventory;
  constructor(
    private inventoryservice: InventoryService,
    private routerservice: RouterService
  ) {
    this.inventories1 = new Inventory();
  }

  ngOnInit(): void {
    // getsearchedFlights
    // this.inventoryservice.getsearchedFlights(this.inventories).subscribe({
    //   next: (res) => {
    //     console.log(res);
    //     this.inventories = res;
    //   },
    //   error: (e) => {
    //     console.log(e);
    //     Swal.fire('Error', 'Get All Airlines', 'error');
    //   },
    // });
    // this.SearchInventory();
  }
  SearchInventory() {
    // debugger;
    // this.inventories1.fromPlace="Pune";
    // this.inventories1.toPlace="Mumbai";
    // this.inventories1.startDateTime=
    debugger;
    // this.inventories1.roundTrip=false;
    this.inventoryservice.getsearchedFlights(this.inventories1).subscribe({
      
      next: (res) => {
         debugger;
        console.log(res);
        this.inventories = res;
      },
      error: (e) => {
        console.log(e);
      },
    });
  }
  gotoBookTicket(){
    this.routerservice.gotoBookticket();
  }
}
