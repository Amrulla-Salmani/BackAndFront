import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplaySearchedInventoryComponent } from './display-searched-inventory.component';

describe('DisplaySearchedInventoryComponent', () => {
  let component: DisplaySearchedInventoryComponent;
  let fixture: ComponentFixture<DisplaySearchedInventoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DisplaySearchedInventoryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DisplaySearchedInventoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
