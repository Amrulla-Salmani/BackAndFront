import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-display-searched-inventory',
  templateUrl: './display-searched-inventory.component.html',
  styleUrls: ['./display-searched-inventory.component.css']
})
export class DisplaySearchedInventoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
