import { Component, OnInit } from '@angular/core';
import { Register } from 'src/app/Model/register';
import { RegisterService } from 'src/app/Services/register.service';
import { RouterService } from 'src/app/Services/router.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent implements OnInit {
  register: Register;
  constructor(
    private registerservice: RegisterService,
    private routerservice: RouterService
  ) {
    console.log('Register Constructor');
    this.register = new Register();
  }

  ngOnInit(): void {}
  registerUser() {
    // debugger;
    this.registerservice.registerUser(this.register).subscribe((res: any) => {
      console.log(`The Add Airline Result:${res}`);
      // debugger;
      if (res == true) {
        Swal.fire('User Details', 'Added Succesfully!!', 'success');
        this.routerservice.gotoLogin();
      }
    });
  }
}
