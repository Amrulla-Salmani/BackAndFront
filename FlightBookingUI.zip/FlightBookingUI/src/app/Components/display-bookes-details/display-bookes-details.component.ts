import { Component, OnInit } from '@angular/core';
import { Ticketbooking } from 'src/app/Model/ticketbooking';
import { BookingService } from 'src/app/Services/booking.service';
import { RouterService } from 'src/app/Services/router.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-display-bookes-details',
  templateUrl: './display-bookes-details.component.html',
  styleUrls: ['./display-bookes-details.component.css'],
})
export class DisplayBookesDetailsComponent implements OnInit {
  DataToSearch: Ticketbooking;
  DisplayBookedDetails?: Ticketbooking[];
  ValidationForTicketCancel?: Ticketbooking;
  constructor(
    private bookingservice: BookingService,
    private routerservice: RouterService
  ) {
    this.DataToSearch = new Ticketbooking();
    this.ValidationForTicketCancel = new Ticketbooking();
  }

  ngOnInit(): void {}
  displayDetailsByPNR() {
    this.bookingservice.getBookedDetailsByPNR(this.DataToSearch).subscribe({
      next: (res) => {
        console.log(res);
        this.DisplayBookedDetails = res; //Correct Code
      },
      error: (e) => {
        console.log(e);
        Swal.fire('Error', 'Details BY PNR', 'error');
      },
    });
  }
  displayHistoryByEmail() {
    this.bookingservice.getBookedHistoryByEmail(this.DataToSearch).subscribe({
      next: (res) => {
        console.log(res);
        this.DisplayBookedDetails = res;
      },
      error: (e) => {
        console.log(e);
        Swal.fire('Error', 'Details BY Email', 'error');
      },
    });
  }
  CancelTicketByPNR() {
    // if (this.checkApplicableOrnotToCancelTicket()) {
      debugger;
      this.bookingservice
        .CancelTicketByPNR(this.DataToSearch)
        .subscribe((res: any) => {
          if (res == true) {
            debugger;
            Swal.fire('Success', 'Ticket Cancelled', 'success');
          } else {
            debugger;
            Swal.fire('Error', 'Ticket Not Cancelled', 'error');
          }
        });
    // }
  }
  // checkApplicableOrnotToCancelTicket() {
  //   this.bookingservice.getBookedDetailsByPNR(this.DataToSearch).subscribe({
  //     next: (res) => {
  //       // this.DisplayBookedDetails = res; 
  //       if(true)
  //       {

  //       }
  //     },
  //     error: (e) => {
  //       // Swal.fire('Error', 'Details BY PNR', 'error');
  //     },
  //   });
  //   return true;
  // }
}
