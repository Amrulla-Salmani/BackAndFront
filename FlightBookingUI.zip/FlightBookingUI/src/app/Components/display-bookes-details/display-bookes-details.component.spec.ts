import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplayBookesDetailsComponent } from './display-bookes-details.component';

describe('DisplayBookesDetailsComponent', () => {
  let component: DisplayBookesDetailsComponent;
  let fixture: ComponentFixture<DisplayBookesDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DisplayBookesDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DisplayBookesDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
