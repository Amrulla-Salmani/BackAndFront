import { Component, OnInit } from '@angular/core';
import { Airline } from 'src/app/Model/airline';
import { AirlineService } from 'src/app/Services/airline.service';
import { RouterService } from 'src/app/Services/router.service';
// import { UserService } from 'src/app/Services/user.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-display-airline',
  templateUrl: './display-airline.component.html',
  styleUrls: ['./display-airline.component.css'],
})
export class DisplayAirlineComponent implements OnInit {
  errorMessage?: string = 'Get All Airlines Details';
  airlines?: Airline[];
  airline: Airline;
  constructor(private airlineService: AirlineService,private routerservice:RouterService) {
    console.log('Display Airline');
    this.airline = new Airline();
  }

  ngOnInit(): void {
    // this.airlineService.getAllAirlines().subscribe(res => {
    //   console.log(res);
    //   this.airlines = res;
    // });

    this.airlineService.getAllAirlines().subscribe({
      next: (res) => {
        console.log(res);
        this.airlines = res;
      },
      error: (e) => {
        console.log(e);
        Swal.fire('Error', 'Get All Airlines', 'error');
      },
    });
  }
  BlockAirline(air: Airline) {
    this.airlineService.BlockAirline(air).subscribe({
      next: (res) => {
        // console.log(res);
        Swal.fire('Success', 'Updated  successfully', 'success');
        this.routerservice.gotoAddAndDisplayAirline();
      },
      error: (e) => {
        // console.log(e);
        Swal.fire('Error', 'Error In Block an Airline', 'error');
      },
      // },}  {
      //   console.log(`The Add Airline Result:${res}`);
      // if (res == true) {
      //   debugger;
      //   Swal.fire('Airline Details', 'Added Succesfully!!', 'success');
      //   // this.routerservice.gotoDisplayAirline();
      //   // this.routerservice.gotoAirlines();
      // } else {
      //   debugger;
      //   // this.routerservice.gotoLogin();
      // }
    });
  }
}
