import { Component, OnInit } from '@angular/core';
import { Router, Routes } from '@angular/router';
import { Airline } from 'src/app/Model/airline';
import { AirlineService } from 'src/app/Services/airline.service';
import { RouterService } from 'src/app/Services/router.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-airline',
  templateUrl: './add-airline.component.html',
  styleUrls: ['./add-airline.component.css'],
})
export class AddAirlineComponent implements OnInit {
  airline: Airline;
  constructor(
    private airlineService: AirlineService,
    private routerservice: RouterService
  ) {
    this.airline = new Airline();
  }

  ngOnInit(): void {
    // this.airline.airlineName = 'Hello24';
    // this.airline.contactNo = 992;
    // this.airline.contactAddr = 'Hello24';
    // this.airlineService.addAirline(this.airline).subscribe((res: any) => {
    //   console.log(`The Add Airline Result:${res}`);
    //   if (res == true) {
    //     this.routerservice.gotoDisplayAirline();
    //   }
    //   else {
    //     this.routerservice.gotoLogin();
    //   }
    // });
  }
  addAirline() {
    this.airlineService.addAirline(this.airline).subscribe((res: any) => {
      console.log(`The Add Airline Result:${res}`);
      if (res == true) {
        Swal.fire('Airline Details', 'Added Succesfully!!', 'success');
        this.routerservice.gotoDisplayAirline();
        // this.routerservice.gotoAirlines();
      } else {
        this.routerservice.gotoLogin();
      }
    });
  }
}
