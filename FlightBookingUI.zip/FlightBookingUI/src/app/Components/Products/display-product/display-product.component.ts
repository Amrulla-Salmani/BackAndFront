import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/Model/product';
import { ProductService } from 'src/app/Services/product.service';

@Component({
  selector: 'app-display-product',
  templateUrl: './display-product.component.html',
  styleUrls: ['./display-product.component.css']
})
export class DisplayProductComponent implements OnInit {
  products?: Product[];
  constructor(private productService: ProductService) { }

    ngOnInit(): void {
    this.productService.getAllProduct().subscribe(res => {
      console.log(res);
      this.products = res;

    });
  }

}
