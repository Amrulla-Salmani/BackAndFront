import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserLoginInfo } from 'src/app/Model/user-login-info';
import { RouterService } from 'src/app/Services/router.service';
import { UserService } from 'src/app/Services/user.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  logininfo: UserLoginInfo;
  constructor(
    private routerservice: RouterService,
    private userservice: UserService,
    private formBuilder: FormBuilder
  ) {
    console.log('Login Constructor');
    this.logininfo = new UserLoginInfo();
    this.loginForm = formBuilder.group({
      name: [
        '',
        Validators.compose([Validators.required, Validators.minLength(5)]),
      ],
      password: [
        '',
        Validators.compose([Validators.required, Validators.minLength(5)]),
      ],
    });
  }

  ngOnInit(): void {
    // this.userLogin();
  }
  userLogin(loginForm: FormGroup) {
    debugger;
    this.logininfo = loginForm.value;
    // this.logininfo.name = 'Bilal';
    // this.logininfo.password = 'Bilal';
    this.userservice.LoginUser(this.logininfo).subscribe({
      next: (res) => {
        debugger;
        console.log(res);
        let jsonObjectDetails = JSON.stringify(res);
        let userRequiredToken = JSON.parse(jsonObjectDetails);
        console.log(`TOKEN afeter Login ::::::${userRequiredToken['token']}`);
        this.routerservice.SetUserToken(userRequiredToken['token']);
        // this.routerservice.gotoAirlines();
        this.routerservice.gotoDisplayAirline();
      },
      error: (e) => {
        debugger;
        console.log(e);
        Swal.fire('Login Failed', 'Please Enter Correct User Name or Password', 'error');
      },
    });
  }
}
