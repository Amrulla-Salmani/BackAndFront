import { Component, OnInit } from '@angular/core';
import { Airline } from 'src/app/Model/airline';
import { Ticketbooking } from 'src/app/Model/ticketbooking';
import { AirlineService } from 'src/app/Services/airline.service';
import { BookingService } from 'src/app/Services/booking.service';
import { RouterService } from 'src/app/Services/router.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-bookings',
  templateUrl: './bookings.component.html',
  styleUrls: ['./bookings.component.css'],
})
export class BookingsComponent implements OnInit {
  ticketbooking: Ticketbooking;
  airlines?: Airline[];
  constructor(
    private bookingservice: BookingService,
    private airlineservice:AirlineService
  ) // ,private airlineService: RouterService
  {
    this.ticketbooking = new Ticketbooking();
  }

  ngOnInit(): void {
    debugger;
    this.airlineservice.getAllAirlines().subscribe({
      next: (res) => {
        debugger;
        console.log(res);
        this.airlines = res;
      },
      error: (e) => {
        debugger;
        console.log(e);
        Swal.fire('Error', 'Get All Airlines', 'error');
      },
    });
  }
  Ticketbook() {
    // debugger;
    // this.bookingservice.BookTicket(this.ticketbooking).subscribe((res: any) => {
    //   debugger;
    //   console.log(`The Add Airline Result:${res}`);
    //   debugger;
    //   if (res == true) {
    //     Swal.fire('Ticket Details', 'Booked Succesfully!!', 'success');

    //   } else {
    //     this.routerservice.gotoLogin();
    //   }
    // });

    this.bookingservice.BookTicket(this.ticketbooking).subscribe({
      next: (res) => {
        // console.log(res);
        // let jsonObjectDetails = JSON.stringify(res);
        // let userRequiredToken = JSON.parse(jsonObjectDetails);
        // console.log(`TOKEN afeter Login ::::::${userRequiredToken['PNR']}`);
        // debugger;
        // let jsonObjectDetails = JSON.stringify(res);
        Swal.fire('Booked Succesfully!! ', ` PNR No is    ${res}`,'success');
      },
      error: (e) => {
        // debugger;
        console.log(e);
        Swal.fire(
          'Ticket Booking Failed',
          'Booked UnSuccesfull',
          'error'
        );
      },
    });
    // this.bookingservice.BookTicket(this.ticketbooking).subscribe((res: any) => {
    //   debugger
    //   console.log(`The Add Airline Result:${res}`);
    //   if (res == true) {
    //     Swal.fire('Airline Details', 'Added Succesfully!!', 'success');
    //     // this.routerservice.gotoDisplayAirline();
    //     // this.routerservice.gotoAirlines();
    //   } else {
    //     // this.routerservice.gotoLogin();
    //   }
    // });


  }
}
