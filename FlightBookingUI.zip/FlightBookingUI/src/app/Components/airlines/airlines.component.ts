import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-airlines',
  templateUrl: './airlines.component.html',
  styleUrls: ['./airlines.component.css']
})
export class AirlinesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
