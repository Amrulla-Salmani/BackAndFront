export class UserLoginInfo {
  name?: string;
  password?: string;
}
