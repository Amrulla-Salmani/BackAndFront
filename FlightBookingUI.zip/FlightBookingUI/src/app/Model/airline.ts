export class Airline {
    airlineId?: number;
    airlineName?: string;
    contactNo?: number;
    contactAddr?: string;
    isBlock?:boolean;
}
