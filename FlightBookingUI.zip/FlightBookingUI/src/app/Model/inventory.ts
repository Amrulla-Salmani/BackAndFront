export class Inventory {
  invId?: number;
  flightId?: number;
  airId?: number;//Foreign Key
  fromPlace?: string;
  toPlace?: string;
  startDateTime?: Date;
  endDateTime?: Date;
  instrumentUsed?: string;
  businessClsSeat?: number;
  nonBusinessClsSeat?: number;
  cost?: number;
  noOfRows?: number;
  meal?: string;
  roundTrip?: boolean;
  Blocked?:boolean;
}
