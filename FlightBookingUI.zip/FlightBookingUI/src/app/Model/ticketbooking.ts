export class Ticketbooking {
  bookingId?: number;
  name?: string;
  email?: string;
  noOfSeatsToBook?: number;
  optForMeal?: string;
  seatNumbers?: string;
  inventoryId?: number;
  bookingDate?: Date;
  pnrNo?: string;
}
