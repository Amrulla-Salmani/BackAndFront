export class Register {
  id?: number;
  name?: string;
  password?: string;
  confirmPassword?: string;
  location?: string;
  role?: string;
}
