export class SearchInventory {
  fromPlace?: string;
  toPlace?: string;
  startDateTime?: Date;
  roundTrip?: boolean;
}
