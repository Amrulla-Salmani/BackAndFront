import { SearchInventory } from './search-inventory';

describe('SearchInventory', () => {
  it('should create an instance', () => {
    expect(new SearchInventory()).toBeTruthy();
  });
});
