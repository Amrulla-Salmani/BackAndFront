import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Register } from '../Model/register';

@Injectable({
  providedIn: 'root',
})
export class RegisterService {
  constructor(private httpclient: HttpClient) {}

  registerUser(register: Register): Observable<boolean> {
    return this.httpclient.post<boolean>(
      'https://localhost:5001/api/v1.0/User/register',
      register
    );
  }
}
