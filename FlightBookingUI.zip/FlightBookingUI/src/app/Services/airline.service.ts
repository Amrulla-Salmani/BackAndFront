import { HttpClient, ɵHttpInterceptingHandler } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Airline } from '../Model/airline';

@Injectable({
  providedIn: 'root',
})
export class AirlineService {
  constructor(private httpclient: HttpClient) {}

  addAirline(airline: Airline): Observable<boolean> {
    return this.httpclient.post<boolean>(
      'https://localhost:5005/api/v1.0/flight/Airline/Register',
      airline
    );
  }

  getAllAirlines(): Observable<Airline[]> {
    return this.httpclient.get<Airline[]>(
      'https://localhost:5005/api/v1.0/flight/Airline/GetAllAirlines'
    );
  }
  BlockAirline(airline: Airline): Observable<boolean> {
    return this.httpclient.put<boolean>(
      'https://localhost:5005/api/v1.0/flight/Airline/BlockAirline'+
      '/' + airline.airlineId, airline.airlineId
    );
  }

  // CancelTicketByPNR(ticketbooking: Ticketbooking): Observable<boolean> {
  //   return this.httpclient.delete<boolean>(
  //     'https://localhost:5009/api/v1.0/flight/TicketBooking/CancelTicket' +
  //       '/' +
  //       ticketbooking.pnrNo
  //   );
  // }
}
