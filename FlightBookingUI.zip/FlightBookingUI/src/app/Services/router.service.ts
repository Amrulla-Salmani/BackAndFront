import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class RouterService {



  constructor(private router:Router) { }
  gotoLogin(){
    this.router.navigate(['login']);
  }
  gotoAddAndDisplayAirline(){
    this.router.navigate(['app-airlines']);
    
  }
  gotoBookticket(){
    this.router.navigate(['Book-ticket']);
  }
  gotoDisplayAirline(){
    // this.router.navigate(['displayairline']);
    this.router.navigate(['display-airline']);//this should be our path which is mentioned in our app.model.routing
    // this.router.navigate(['add-airline']);
    // this.router.navigate(['airlines']);
  }
  gotoAddInventory() {
    this.router.navigate(['add-inventory']);
  }

  gotoInventories(){
    this.router.navigate(['display-inventory']);
  }
  gotoAirlines()
  {
    this.router.navigate(['airlines']);
  }
  SetUserToken(userToken: string) {
    localStorage.setItem("USERTOKEN", userToken);
  }
  clearLocalStorage() {
    localStorage.clear();
  }
  getUserToken() {
    return localStorage.getItem("USERTOKEN");
}
}
