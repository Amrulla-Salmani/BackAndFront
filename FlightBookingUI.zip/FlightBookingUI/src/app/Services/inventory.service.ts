import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Inventory } from '../Model/inventory';

@Injectable({
  providedIn: 'root'
})
export class InventoryService {

  constructor(private httpclient:HttpClient) { }

  addInventory(inventory:Inventory): Observable<boolean> {
    debugger;
    return this.httpclient.post<boolean>('https://localhost:5007/api/v1.0/flight/Add/RegisterInventory',inventory);
  }

  getAllInventories(): Observable<Inventory[]> {
    debugger;
    return this.httpclient.get<Inventory[]>('https://localhost:5007/api/v1.0/flight/Add/GetAllFlights');
  }
  getsearchedFlights(inventory:Inventory): Observable<Inventory[]>
  {
    // debugger;
    return this.httpclient.post<Inventory[]>('https://localhost:5007/api/v1.0/flight/Add/SearchFlights',inventory);
  }
  
}
