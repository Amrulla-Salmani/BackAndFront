import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { UserLoginInfo } from '../Model/user-login-info';
import { RouterService } from './router.service';

@Injectable({
  providedIn: 'root'
})
export class UserService {


  // constructor(private routerservice:RouterService,private userservice:UserService) { }
  constructor(private httpclient:HttpClient) { }

  LoginUser(logininfo: UserLoginInfo):Observable<string> {
    console.log(`User Login Details in Service Layer${logininfo}`);
    
   return this.httpclient.post<string>('https://localhost:5001/api/v1.0/User/login',logininfo)
  }
}
