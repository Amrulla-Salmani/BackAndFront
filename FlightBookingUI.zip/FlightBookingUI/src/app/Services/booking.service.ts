import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { observable, Observable } from 'rxjs';
import { Ticketbooking } from '../Model/ticketbooking';

@Injectable({
  providedIn: 'root',
})
export class BookingService {
  constructor(private httpclient: HttpClient) {}

  BookTicket(ticketbooking: Ticketbooking): Observable<string> {
    // console.log(`Ticket Details in Service Layer${ticketbooking}`);
    return this.httpclient.post<string>(
      'https://localhost:5009/api/v1.0/flight/TicketBooking/BookTicket',
      ticketbooking
    );
  }
  getBookedDetailsByPNR(
    ticketbooking: Ticketbooking
  ): Observable<Ticketbooking[]> {
    return this.httpclient.get<Ticketbooking[]>(
      'https://localhost:5009/api/v1.0/flight/TicketBooking/getBookingDetailsByPNR' +
        '/' +
        ticketbooking.pnrNo
    );
  }
  getBookedHistoryByEmail(
    ticketbooking: Ticketbooking
  ): Observable<Ticketbooking[]> {
    debugger;
    //  let param1 = new HttpParams().set('email', `${ticketbooking.email}`);
    return this.httpclient.get<Ticketbooking[]>(
      'https://localhost:5009/api/v1.0/flight/TicketBooking/getHistoryByEmail' +
        '/' +
        ticketbooking.email
    );
  }

  CancelTicketByPNR(ticketbooking: Ticketbooking): Observable<boolean> {
    return this.httpclient.delete<boolean>(
      'https://localhost:5009/api/v1.0/flight/TicketBooking/CancelTicket' +
        '/' +
        ticketbooking.pnrNo
    );
  }
}
