import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { AppComponent } from './app.component';
import { LoginComponent } from './Components/login/login.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NavComponent } from './nav/nav.component';
import { LayoutModule } from '@angular/cdk/layout';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { LogoutComponent } from './Components/logout/logout.component';
import { RegisterComponent } from './Components/register/register.component';
import { AppRoutingModule } from './app-routing/app-routing.module';
import { AddProductComponent } from './Components/Products/add-product/add-product.component';
import { DisplayProductComponent } from './Components/Products/display-product/display-product.component';
import { HttpClientModule } from '@angular/common/http';
import { MatFormFieldControl, MatFormFieldModule } from '@angular/material/form-field';
import { MatCardModule } from '@angular/material/card';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatInputModule } from '@angular/material/input';
// import { AirlineComponent } from './Components/airline/airline.component';
import { AddAirlineComponent } from './Components/Airline/add-airline/add-airline.component';
import { DisplayAirlineComponent } from './Components/Airline/display-airline/display-airline.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AirlinesComponent } from './Components/airlines/airlines.component';
import { AddInventoryComponent } from './Components/Inventory/add-inventory/add-inventory.component';
import { DisplayInventoryComponent } from './Components/Inventory/display-inventory/display-inventory.component';
import { MatNativeDateModule, MatOption } from '@angular/material/core';
// import { InventoryComponent } from './Components/Inventory/inventory.component';
// import { InventoryComponent } from './Components/inventory/inventory.component';
import {MatRadioModule} from '@angular/material/radio';
import { BookingsComponent } from './Components/bookings/bookings.component';
import { SeachInventoryComponent } from './Components/Inventory/seach-inventory/seach-inventory.component';
import { DisplaySearchedInventoryComponent } from './Components/Inventory/display-searched-inventory/display-searched-inventory.component';
import { DisplayBookesDetailsComponent } from './Components/display-bookes-details/display-bookes-details.component';
// import { DisplayBookingsComponent } from './Components/bookings/display-bookings/display-bookings.component';
import { MatSelectModule } from '@angular/material/select';
import {MatCheckboxModule} from '@angular/material/checkbox';



@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    NavComponent,
    LogoutComponent,
    RegisterComponent,
    AddProductComponent,
    DisplayProductComponent,
    // AirlineComponent,
    AddAirlineComponent,
    DisplayAirlineComponent,
    AirlinesComponent,
    AddInventoryComponent,
    DisplayInventoryComponent,
    BookingsComponent,
    SeachInventoryComponent,
    DisplaySearchedInventoryComponent,
    DisplayBookesDetailsComponent,
    // DisplayBookingsComponent,
    // InventoryComponent,
    // InventoryComponent

  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    LayoutModule,
    MatToolbarModule,
    MatButtonModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    AppRoutingModule,
    HttpClientModule,
    MatFormFieldModule,
    MatCardModule,
    MatExpansionModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatRadioModule,
    MatSelectModule,
    MatCheckboxModule
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
